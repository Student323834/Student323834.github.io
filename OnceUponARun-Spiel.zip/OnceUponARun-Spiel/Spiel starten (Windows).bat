@echo off
REM Once Upon a Run - starts a small local web server and opens the game in the browser.
cd /d "%~dp0spiel"
set PORT=8765
echo.
echo   Once Upon a Run: http://localhost:%PORT%
echo   Close this window to stop the game server.
echo.
start "" "http://localhost:%PORT%/"
where python >nul 2>nul && (python -m http.server %PORT% & goto :eof)
where py >nul 2>nul && (py -m http.server %PORT% & goto :eof)
where npx >nul 2>nul && (npx --yes serve -l %PORT% . & goto :eof)
echo Python or Node.js was not found. Please install Python from https://www.python.org/downloads/ and run this file again.
pause
