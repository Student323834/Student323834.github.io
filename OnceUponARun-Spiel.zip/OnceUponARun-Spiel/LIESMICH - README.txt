ONCE UPON A RUN – A FAIRYTALE ADVENTURE
3D endless runner controlled by hand gestures (MediaPipe HandLandmarker + Three.js)
======================================================================================

DEUTSCH – So startest du das Spiel
-----------------------------------
1. ZIP entpacken.
2. Doppelklick auf:
     Mac:      "Spiel starten (Mac).command"
     Windows:  "Spiel starten (Windows).bat"
   Der Browser öffnet sich automatisch mit http://localhost:8765
3. Am besten Google Chrome verwenden. "Start Game" klicken und den Kamerazugriff erlauben.

Mac-Hinweis: Falls macOS meldet, die Datei sei von einem "nicht verifizierten Entwickler",
Rechtsklick auf die Datei -> "Öffnen" -> "Öffnen" bestätigen.
Ohne Start-Datei: Terminal im Ordner "spiel" öffnen und  python3 -m http.server 8765  eingeben,
dann http://localhost:8765 im Browser öffnen.

Wichtig: index.html NICHT direkt per Doppelklick öffnen – Browser blockieren dann das Laden
des Handmodells. Das Spiel braucht den kleinen lokalen Server (Start-Datei).
Alles läuft lokal und offline; es werden keine Kamerabilder hochgeladen oder gespeichert.

ENGLISH – How to start the game
-------------------------------
1. Unzip.
2. Double-click "Spiel starten (Mac).command" (macOS) or "Spiel starten (Windows).bat" (Windows).
   The browser opens http://localhost:8765 automatically.
3. Use Google Chrome, click "Start Game" and allow camera access.
macOS: if the file is blocked ("unidentified developer"), right-click it -> Open -> Open.
Without the start file: open a terminal in the "spiel" folder, run  python3 -m http.server 8765
and open http://localhost:8765. Do NOT open index.html directly (file://) – the model cannot load then.
Everything runs locally/offline. No webcam images are uploaded or stored.

CONTROLS / STEUERUNG
--------------------
Move hand left / middle / right ...... change lane
Quick swipe up / down ................ jump / slide
Hold a peace sign (two fingers) ...... sprint
Show both hands ...................... magic shield
Take the hand out of view ............ auto pause
Esc .................................. back to the start page
Keyboard debug mode (Settings): arrows, space, S, Shift, P, D (debug panel)
