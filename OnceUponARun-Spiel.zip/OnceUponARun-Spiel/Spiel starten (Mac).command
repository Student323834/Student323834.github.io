#!/bin/bash
# Once Upon a Run – startet einen kleinen lokalen Webserver und öffnet das Spiel im Browser.
cd "$(dirname "$0")/spiel" || exit 1
PORT=8765
echo ""
echo "  Once Upon a Run läuft auf http://localhost:$PORT"
echo "  Zum Beenden dieses Fenster schließen (oder Ctrl+C)."
echo ""
( sleep 1.5; open "http://localhost:$PORT/" ) &
python3 -m http.server "$PORT"
